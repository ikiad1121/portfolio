const datas = {
    "1":["新大阪駅","梅田駅","淀屋橋駅","本町駅","なんば駅","天王寺駅"],
    "2":["東梅田駅","天満橋駅","谷町9丁目駅","天王寺駅"],
    "3":["西梅田駅","本町駅","なんば駅"],
    "4":["弁天町駅","九条駅","本町駅","森ノ宮駅"],
    "5":["野田阪神駅","なんば駅","谷町9丁目駅","鶴橋駅"]
};

const firstVote1 = document.getElementById("first-vote1");
const secondVote1 = document.getElementById("second-vote1");

const firstVote2 = document.getElementById("first-vote2");
const secondVote2 = document.getElementById("second-vote2");

const firstVote3 = document.getElementById("first-vote3");
const secondVote3 = document.getElementById("second-vote3");

firstVote1.addEventListener('change', ()=>{
    secondVote1.innerHTML = '<option hidden>選択してください</option>';
    firstVote2.innerHTML = '<option hidden>選択できません</option>';
    secondVote2.innerHTML = '<option hidden>選択できません</option>';
    firstVote3.innerHTML = '<option hidden>選択できません</option>';
    secondVote3.innerHTML = '<option hidden>選択できません</option>';

    if(firstVote1.value){
        for(var i1 = 0; i1 < datas[firstVote1.value].length; i1++){
            secondVote1.innerHTML += `<option value="${datas[firstVote1.value][i1]}">${datas[firstVote1.value][i1]}</option>`;
        }
    }else{
        secondVote1.innerHTML = '<option hidden>選択できません</option>';
    }
});

secondVote1.addEventListener('change', ()=>{
    firstVote2.innerHTML = `
                            <option hidden>選択してください</option>
                            <option value="御堂筋線">御堂筋線</option>
                            <option value="谷町線">谷町線</option>
                            <option value="四つ橋線">四つ橋線</option>
                            <option value="中央線">中央線</option>
                            <option value="千日前線">千日前線</option>
                        `;
    secondVote2.innerHTML = '<option hidden>選択できません</option>';
    firstVote3.innerHTML = '<option hidden>選択できません</option>';
    secondVote3.innerHTML = '<option hidden>選択できません</option>';

    firstVote2.addEventListener('change', ()=>{
        secondVote2.innerHTML = '<option hidden>選択してください</option>';

        if(firstVote2.value){
            for(var i1 = 0; i1 < datas[firstVote2.value].length; i1++){
                if(secondVote1.value != datas[firstVote2.value][i1]){
                    secondVote2.innerHTML += `<option value="${datas[firstVote2.value][i1]}">${datas[firstVote2.value][i1]}</option>`;
                }
            }
        }else{
            secondVote2.innerHTML = '<option hidden>選択できません</option>';
        }
    });
});

secondVote2.addEventListener('change', ()=>{
    firstVote3.innerHTML = `
                            <option hidden>選択してください</option>
                            <option value="御堂筋線">御堂筋線</option>
                            <option value="谷町線">谷町線</option>
                            <option value="四つ橋線">四つ橋線</option>
                            <option value="中央線">中央線</option>
                            <option value="千日前線">千日前線</option>
                        `;
    secondVote3.innerHTML = '<option hidden>選択できません</option>';

    firstVote3.addEventListener('change', ()=>{
        secondVote3.innerHTML = '<option hidden>選択してください</option>';

        if(firstVote3.value){
            for(var i1 = 0; i1 < datas[firstVote3.value].length; i1++){
                if(
                    secondVote2.value != datas[firstVote3.value][i1]
                    &&secondVote1.value != datas[firstVote3.value][i1]
                ){
                    secondVote3.innerHTML += `<option value="${datas[firstVote3.value][i1]}">${datas[firstVote3.value][i1]}</option>`;
                }
            }
        }else{
            secondVote3.innerHTML = '<option hidden>選択できません</option>';
        }
    });
});