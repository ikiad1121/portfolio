<?php
    session_start();
    $_SESSION['err'] = false;

    if(isset($_POST["second-vote1"])){
        if($_POST["second-vote1"] != "選択してください"){
            $firstVote1 = $_POST["first-vote1"];
            $secondVote1 = $_POST["second-vote1"];
            $thirdVote1 = $_POST["third-vote1"];
            $firstVote2 = '';
            $secondVote2 = '';
            $thirdVote2 = '';
            $firstVote3 = '';
            $secondVote3 = '';
            $thirdVote3 = '';
            $firstVote4 = '';
            $secondVote4 = '';
            $thirdVote4 = '';
            $firstVote5 = '';
            $secondVote5 = '';
            $thirdVote5 = '';
            $firstVote6 = '';
            $secondVote6 = '';
            $thirdVote6 = '';
            $firstVote7 = '';
            $secondVote7 = '';
            $thirdVote7 = '';
        }else{
            $_SESSION['err'] = true;
            header('location: main.php');
        }
    }else{
        $_SESSION['err'] = true;
        header('location: main.php');
    }

    if(isset($_POST["second-vote2"])){
        if($_POST["second-vote2"] != "選択してください"){
            $firstVote2 = $_POST["first-vote2"];
            $secondVote2 = $_POST["second-vote2"];
            $thirdVote2 = $_POST["third-vote2"];
            $firstVote3 = '';
            $secondVote3 = '';
            $firstVote4 = '';
            $secondVote4 = '';
            $firstVote5 = '';
            $secondVote5 = '';
            
            $_SESSION['first-vote2-sub'] = $firstVote2;
            $_SESSION['second-vote2-sub'] = $secondVote2;
            $_SESSION['third-vote2-sub'] = $thirdVote2;
        }else{
            $_SESSION['err21'] = true;
        }
    }else{
        $_SESSION['err21'] = true;
    }

    if(isset($_POST["second-vote3"])){
        if($_POST["second-vote3"] != "選択してください"){
            $firstVote3 = $_POST["first-vote3"];
            $secondVote3 = $_POST["second-vote3"];
            $thirdVote3 = $_POST["third-vote3"];
            $firstVote4 = '';
            $secondVote4 = '';
            $firstVote5 = '';
            $secondVote5 = '';
            
            $_SESSION['first-vote3-sub'] = $firstVote3;
            $_SESSION['second-vote3-sub'] = $secondVote3;
            $_SESSION['third-vote3-sub'] = $thirdVote3;
        }else{
            $_SESSION['err31'] = true;
        }
    }else{
        $_SESSION['err31'] = true;
    }

    if(isset($_POST["second-vote4"])){
        if($_POST["second-vote4"] != '選択してください'){
            $firstVote4 = $_POST["first-vote4"];
            $secondVote4 = $_POST["second-vote4"];
            $thirdVote4 = $_POST["third-vote4"];
            
            $_SESSION['first-vote4-sub'] = $firstVote4;
            $_SESSION['second-vote4-sub'] = $secondVote4;
            $_SESSION['third-vote4-sub'] = $thirdVote4;
        }
    }

    if(isset($_POST["second-vote5"])){
        if($_POST["second-vote5"] != '選択してください'){
            $firstVote5 = $_POST["first-vote5"];
            $secondVote5 = $_POST["second-vote5"];
            $thirdVote5 = $_POST["third-vote5"];
            
            $_SESSION['first-vote5-sub'] = $firstVote5;
            $_SESSION['second-vote5-sub'] = $secondVote5;
            $_SESSION['third-vote5-sub'] = $thirdVote5;
        }
    }

    if(isset($_POST["second-vote6"])){
        if($_POST["second-vote6"] != '選択してください'){
            $firstVote6 = $_POST["first-vote6"];
            $secondVote6 = $_POST["second-vote6"];
            $thirdVote6 = $_POST["third-vote6"];
            
            $_SESSION['first-vote6-sub'] = $firstVote6;
            $_SESSION['second-vote6-sub'] = $secondVote6;
            $_SESSION['third-vote6-sub'] = $thirdVote6;
        }
    }

    if(isset($_POST["second-vote7"])){
        if($_POST["second-vote7"] != '選択してください'){
            $firstVote7 = $_POST["first-vote7"];
            $secondVote7 = $_POST["second-vote7"];
            $thirdVote7 = $_POST["third-vote7"];
            
            $_SESSION['first-vote7-sub'] = $firstVote7;
            $_SESSION['second-vote7-sub'] = $secondVote7;
            $_SESSION['third-vote7-sub'] = $thirdVote7;
        }
    }

    //vote writers
    $jsonf = Array();
    $id_flug = true;

    /*$reader = fopen('../assets/api/data1.csv', 'r');
    $reader = mb_convert_encoding($reader, 'UTF-8');*/
    $data = file_get_contents('../assets/api/data1.csv');
    $data = mb_convert_encoding($data, 'UTF-8', 'sjis-win');
    $temp = tmpfile();

    fwrite($temp, $data);
    rewind($temp);

    $i = 0;
    while (($data = fgetcsv($temp, 0, ",")) !== FALSE) {
        $i = $i + 1;
        /*echo '$data[0]'.$data[0];
        echo '$data[1]'.$data[1];
        echo '$data[2]'.$data[2];*/
        if($i > 0){
            array_push(
                $jsonf,
                 [
                    "firstVote1" => $data[0], "secondVote1" => $data[1], "thirdVote1" => $data[2],
                    "firstVote2" => $data[3], "secondVote2" => $data[4], "thirdVote2" => $data[5],
                    "firstVote3" => $data[6], "secondVote3" => $data[7], "thirdVote3" => $data[8],
                    "firstVote4" => $data[9], "secondVote4" => $data[10], "thirdVote4" => $data[11],
                    "firstVote5" => $data[12], "secondVote5" => $data[13], "thirdVote5" => $data[14],
                    "firstVote6" => $data[15], "secondVote6" => $data[16], "thirdVote6" => $data[17],
                    "firstVote7" => $data[18], "secondVote7" => $data[19], "thirdVote7" => $data[20]
                ]
            );
        }
    }
    fclose($temp);

    if($secondVote2){
        array_push(
            $jsonf,
             [
                "firstVote1" => $firstVote1, "secondVote1" => $secondVote1, "thirdVote1" => $thirdVote1,
                "firstVote2" => $firstVote2, "secondVote2" => $secondVote2, "thirdVote2" => $thirdVote2,
                "firstVote3" => $firstVote3, "secondVote3" => $secondVote3, "thirdVote3" => $thirdVote3,
                "firstVote4" => $firstVote4, "secondVote4" => $secondVote4, "thirdVote4" => $thirdVote4,
                "firstVote5" => $firstVote5, "secondVote5" => $secondVote5, "thirdVote5" => $thirdVote5,
                "firstVote6" => $firstVote6, "secondVote6" => $secondVote6, "thirdVote6" => $thirdVote6,
                "firstVote7" => $firstVote7, "secondVote7" => $secondVote7, "thirdVote7" => $thirdVote7
            ]
        );

        $writer = fopen('../assets/api/data1.csv', 'w+b');
        //fputcsv($writer, $jsonf);
        foreach($jsonf as $data){
            mb_convert_variables('SJIS-win', 'UTF-8', $data);
            //fwrite($writer, implode(',' , $data) . "\n");
            fputcsv($writer, $data);
        }
        fclose($writer);
    }
?>
<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="../css/styles.css" />
		<link rel="icon" href="../assets/image/iconF.ico">
        <title>投票アプリ</title>
    </head>
    <body>
        <nav></nav>
        <header></header>
        <main>
            <p>
                投票が完了しました。<br>
                <a href="../index.html">戻る</a>
            </p>
        </main>
        <footer></footer>
    </body>
</html>