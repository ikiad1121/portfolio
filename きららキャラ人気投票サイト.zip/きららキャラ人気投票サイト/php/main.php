<?php
    session_start();

    $errmsg11 = '';
    $errmsg12 = '';
    $errmsg13 = '';
    $errmsg21 = '';
    $errmsg22 = '';
    $errmsg23 = '';
    $errmsg31 = '';
    $errmsg32 = '';
    $errmsg33 = '';
    $errmsg42 = '';
    $errmsg52 = '';
    $errmsg62 = '';
    $errmsg72 = '';
    if(
        isset($_SESSION['err11']) 
        && isset($_SESSION['first-vote1-sub'])
        && isset($_SESSION['second-vote1-sub'])
    ){
        if($_SESSION['err11']){
            $errmsg11 = '<span class="warn">必須項目です</span>';
        }else{
            $errmsg11 = '';
            $errmsg12 = '<script>
                            document.getElementById("third-vote1").disabled = false;
                            document.getElementById("third-vote1").value = "'.$_SESSION['third-vote1-sub'].'";
                        </script>
                        ';
            $errmsg13 = '<script>
                            let datas1;
                            let datas2;
                            const url1 = "../assets/api/titledata";
                            const url2 = "../assets/api/charadata";
                            fetch(url1)
                                .then((res) => res.json()).then((data) => {
                                console.log(data);
                                titleArray1(data);
                            });

                            const titleArray1 = (d) =>{
                                datas1 = d;
                            };

                            fetch(url2)
                                .then((res) => res.json()).then((data) => {
                                console.log(data);
                                charaArray1(data);
                            });

                            const charaArray1 = (d) =>{
                                datas2 = d;

                                document.getElementById("first-vote1").innerHTML = `<option value="'.$_SESSION['first-vote1-sub'].'" hidden>'.$_SESSION['first-vote1-sub'].'</option>`;
                                for(var i1 = 0; i1 < datas1.length; i1++){
                                    firstVote1.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                }
                                document.getElementById("second-vote1").innerHTML = `<option value="'.$_SESSION['second-vote1-sub'].'" hidden>'.$_SESSION['second-vote1-sub'].'</option>`;
                                for(var i1 = 0; i1 < datas2[\''.$_SESSION['first-vote1-sub'].'\'].length; i1++){
                                    secondVote1.innerHTML += `<option value="${datas2[\''.$_SESSION['first-vote1-sub'].'\'][i1]}">${datas2[\''.$_SESSION['first-vote1-sub'].'\'][i1]}</option>`;
                                }
                                document.getElementById("second-vote1").disabled = false;
                                document.getElementById("first-vote2").innerHTML = `<option hidden>選択してください</option>`;
                                for(var i1 = 0; i1 < datas1.length; i1++){
                                    firstVote2.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                }
                                document.getElementById("first-vote2").disabled = false;
                            };
                        </script>
                        ';
        }
    }

    if(
        isset($_SESSION['err21']) 
    ){
        if($_SESSION['err21']){
            $errmsg21 = '<span class="warn">必須項目です</span>';
        }else{
            if(
                isset($_SESSION['first-vote2-sub'])
                && isset($_SESSION['second-vote2-sub'])
            ){
                $errmsg21 = '';
                $errmsg22 = '<script>
                                document.getElementById("third-vote2").disabled = false;
                                document.getElementById("third-vote2").value = "'.$_SESSION['third-vote2-sub'].'";
                            </script>
                            ';
                $errmsg23 = '<script>
                                //let datas1;
                                //let datas2;
                                //const url1 = "../assets/api/titledata";
                                //const url2 = "../assets/api/charadata";
                                fetch(url1)
                                    .then((res) => res.json()).then((data) => {
                                    console.log(data);
                                    titleArray2(data);
                                });

                                const titleArray2 = (d) =>{
                                    datas1 = d;
                                };

                                fetch(url2)
                                    .then((res) => res.json()).then((data) => {
                                    console.log(data);
                                    charaArray2(data);
                                });

                                const charaArray2 = (d) =>{
                                    datas2 = d;

                                    console.log("datas2: ", datas2);

                                    document.getElementById("first-vote1").innerHTML = `<option value="'.$_SESSION['first-vote1-sub'].'" hidden>'.$_SESSION['first-vote1-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas1.length; i1++){
                                        firstVote1.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                    }
                                    document.getElementById("second-vote1").innerHTML = `<option value="'.$_SESSION['second-vote1-sub'].'" hidden>'.$_SESSION['second-vote1-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas2[\''.$_SESSION['first-vote1-sub'].'\'].length; i1++){
                                        secondVote1.innerHTML += `<option value="${datas2[\''.$_SESSION['first-vote1-sub'].'\'][i1]}">${datas2[\''.$_SESSION['first-vote1-sub'].'\'][i1]}</option>`;
                                    }
                                    document.getElementById("second-vote1").disabled = false;

                                    document.getElementById("first-vote2").innerHTML = `<option value="'.$_SESSION['first-vote2-sub'].'" hidden>'.$_SESSION['first-vote2-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas1.length; i1++){
                                        firstVote2.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                    }
                                    document.getElementById("second-vote2").innerHTML = `<option value="'.$_SESSION['second-vote2-sub'].'" hidden>'.$_SESSION['second-vote2-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas2[\''.$_SESSION['first-vote2-sub'].'\'].length; i1++){
                                        secondVote2.innerHTML += `<option value="${datas2[\''.$_SESSION['first-vote2-sub'].'\'][i1]}">${datas2[\''.$_SESSION['first-vote2-sub'].'\'][i1]}</option>`;
                                    }
                                    document.getElementById("second-vote2").disabled = false;

                                    document.getElementById("first-vote3").innerHTML = `<option hidden>選択してください</option>`;
                                    for(var i1 = 0; i1 < datas1.length; i1++){
                                        firstVote3.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                    }
                                    document.getElementById("first-vote3").disabled = false;
                                };
                            </script>
                            ';
            }
        }
    }

    if(isset($_SESSION['err31'])){
        if($_SESSION['err31']){
            $errmsg31 = '<span class="warn">必須項目です</span>';
        }else{
            if(
                isset($_SESSION['first-vote3-sub'])
                && isset($_SESSION['second-vote3-sub'])
            ){
                $errmsg31 = '';
                $errmsg32 = '<script>
                                document.getElementById("third-vote3").disabled = false;
                                document.getElementById("third-vote3").value = "'.$_SESSION['third-vote3-sub'].'";
                            </script>
                            ';
                $errmsg33 = '<script>
                                fetch(url1)
                                    .then((res) => res.json()).then((data) => {
                                    console.log(data);
                                    titleArray3(data);
                                });

                                const titleArray3 = (d) =>{
                                    datas1 = d;
                                };

                                fetch(url2)
                                    .then((res) => res.json()).then((data) => {
                                    console.log(data);
                                    charaArray3(data);
                                });

                                const charaArray3 = (d) =>{
                                    datas2 = d;

                                    console.log("datas2: ", datas2);

                                    document.getElementById("first-vote1").innerHTML = `<option value="'.$_SESSION['first-vote1-sub'].'" hidden>'.$_SESSION['first-vote1-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas1.length; i1++){
                                        firstVote1.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                    }
                                    document.getElementById("second-vote1").innerHTML = `<option value="'.$_SESSION['second-vote1-sub'].'" hidden>'.$_SESSION['second-vote1-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas2[\''.$_SESSION['first-vote1-sub'].'\'].length; i1++){
                                        secondVote1.innerHTML += `<option value="${datas2[\''.$_SESSION['first-vote1-sub'].'\'][i1]}">${datas2[\''.$_SESSION['first-vote1-sub'].'\'][i1]}</option>`;
                                    }
                                    document.getElementById("second-vote1").disabled = false;

                                    document.getElementById("first-vote2").innerHTML = `<option value="'.$_SESSION['first-vote2-sub'].'" hidden>'.$_SESSION['first-vote2-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas1.length; i1++){
                                        firstVote2.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                    }
                                    document.getElementById("second-vote2").innerHTML = `<option value="'.$_SESSION['second-vote2-sub'].'" hidden>'.$_SESSION['second-vote2-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas2[\''.$_SESSION['first-vote2-sub'].'\'].length; i1++){
                                        secondVote2.innerHTML += `<option value="${datas2[\''.$_SESSION['first-vote2-sub'].'\'][i1]}">${datas2[\''.$_SESSION['first-vote2-sub'].'\'][i1]}</option>`;
                                    }
                                    document.getElementById("second-vote2").disabled = false;

                                    document.getElementById("first-vote3").innerHTML = `<option value="'.$_SESSION['first-vote3-sub'].'" hidden>'.$_SESSION['first-vote3-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas1.length; i1++){
                                        firstVote3.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                    }
                                    document.getElementById("second-vote3").innerHTML = `<option value="'.$_SESSION['second-vote3-sub'].'" hidden>'.$_SESSION['second-vote3-sub'].'</option>`;
                                    for(var i1 = 0; i1 < datas2[\''.$_SESSION['first-vote3-sub'].'\'].length; i1++){
                                        secondVote3.innerHTML += `<option value="${datas2[\''.$_SESSION['first-vote3-sub'].'\'][i1]}">${datas2[\''.$_SESSION['first-vote3-sub'].'\'][i1]}</option>`;
                                    }
                                    document.getElementById("second-vote3").disabled = false;

                                    document.getElementById("first-vote4").innerHTML = `<option hidden>選択してください</option>`;
                                    for(var i1 = 0; i1 < datas1.length; i1++){
                                        firstVote4.innerHTML += `<option value="${datas1[i1]}">${datas1[i1]}</option>`;
                                    }
                                    document.getElementById("first-vote4").disabled = false;
                                };
                            </script>
                            ';
            }
        }
    }
    $_SESSION['err11'] = false;
    $_SESSION['err12'] = false;
    $_SESSION['err21'] = false;
    $_SESSION['err22'] = false;
    $_SESSION['err31'] = false;
    $_SESSION['err32'] = false;
    $_SESSION['err42'] = false;
    $_SESSION['err52'] = false;
    $_SESSION['err62'] = false;
    $_SESSION['err72'] = false;
?>
<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="../css/styles.css" />
		<link rel="icon" href="../assets/image/iconF.ico">
        <title>キャラクター部門｜きららキャラ人気投票ページ(非公式)</title>
    </head>
    <body>
        <nav></nav>
        <header></header>
        <main>
            <div class="pagehead">
                <h1>キャラクター部門</h1>
                <p>
                    1番推し～7番推しまで、最大で7人への投票が可能となっております。
                    4番推し～7番推しについては任意ですが、最低でも3人へは投票をしなければなりません。<br>
                    なお、コメント欄も用意しておりますが、こちらは必須項目ではありません。そのキャラクターに並々ならぬ熱意を持っている方はぜひとご活用ください。
                </p>
            </div>
            <div class="pagemid1">
                <form action="check.php" method="POST">
                    <label for="first-vote1">1番(最推し)</label><br>
                    <select id="first-vote1" name="first-vote1">
                        <option hidden>選択してください</option>
                    </select>
                    <label for="second-vote1"></label>
                    <select id="second-vote1" name="second-vote1" disabled>
                        <option>選択できません</option>
                    </select>
                    <span class="required">必須</span>
                    <?php echo $errmsg11 ?>
                    <br>
                    <label for="third-vote1">コメント：</label>
                    <textarea id="third-vote1" name="third-vote1" col="60" row="1" disabled></textarea>
                    <?php echo $errmsg12 ?>
                    <br>
                    ※最推しのところには2票分入ります。
                    <br>
                    <br>
                    <label for="first-vote2">2番</label><br>
                    <select id="first-vote2" name="first-vote2" disabled>
                        <option>選択できません</option>
                        <option hidden>おちこぼれフルーツタルト</option>
                    </select>
                    <?php echo $errmsg13 ?>
                    <label for="second-vote2"></label>
                    <select id="second-vote2" name="second-vote2" disabled>
                        <option hidden>選択できません</option>
                    </select>
                    <span class="required">必須</span>
                    <?php echo $errmsg21 ?>
                    <br>
                    <label for="third-vote2">コメント：</label>
                    <textarea id="third-vote2" name="third-vote2" col="60" row="1" disabled></textarea>
                    <?php echo $errmsg22 ?>
                    <br>
                    <br>
                    <label for="first-vote3">3番</label><br>
                    <select id="first-vote3" name="first-vote3" disabled>
                        <option>選択できません</option>
                        <option hidden>おちこぼれフルーツタルト</option>
                    </select>
                    <?php echo $errmsg23 ?>
                    <label for="second-vote3"></label>
                    <select id="second-vote3" name="second-vote3" disabled>
                        <option hidden>選択できません</option>
                    </select>
                    <span class="required">必須</span>
                    <?php echo $errmsg31 ?>
                    <br>
                    <label for="third-vote3">コメント：</label>
                    <textarea id="third-vote3" name="third-vote3" col="60" row="1" disabled></textarea>
                    <?php echo $errmsg32 ?>
                    <br>
                    <br>
                    <label for="first-vote4">4番</label><br>
                    <select id="first-vote4" name="first-vote4" disabled>
                        <option>選択できません</option>
                        <option hidden>おちこぼれフルーツタルト</option>
                    </select>
                    <?php echo $errmsg33 ?>
                    <label for="second-vote4"></label>
                    <select id="second-vote4" name="second-vote4" disabled>
                        <option hidden>選択できません</option>
                    </select>
                    <br>
                    <label for="third-vote4">コメント：</label>
                    <textarea id="third-vote4" name="third-vote4" col="60" row="1" disabled></textarea>
                    <br>
                    <br>
                    <label for="first-vote5">5番</label><br>
                    <select id="first-vote5" name="first-vote5" disabled>
                        <option>選択できません</option>
                        <option hidden>おちこぼれフルーツタルト</option>
                    </select>
                    <label for="second-vote5"></label>
                    <select id="second-vote5" name="second-vote5" disabled>
                        <option hidden>選択できません</option>
                    </select>
                    <br>
                    <label for="third-vote5">コメント：</label>
                    <textarea id="third-vote5" name="third-vote5" col="60" row="1" disabled></textarea>
                    <br>
                    <br>
                    <label for="first-vote6">6番</label><br>
                    <select id="first-vote6" name="first-vote6" disabled>
                        <option>選択できません</option>
                        <option hidden>おちこぼれフルーツタルト</option>
                    </select>
                    <label for="second-vote6"></label>
                    <select id="second-vote6" name="second-vote6" disabled>
                        <option hidden>選択できません</option>
                    </select>
                    <br>
                    <label for="third-vote6">コメント：</label>
                    <textarea id="third-vote6" name="third-vote6" col="60" row="1" disabled></textarea>
                    <br>
                    <br>
                    <label for="first-vote7">7番</label><br>
                    <select id="first-vote7" name="first-vote7" disabled>
                        <option>選択できません</option>
                        <option hidden>おちこぼれフルーツタルト</option>
                    </select>
                    <label for="second-vote7"></label>
                    <select id="second-vote7" name="second-vote7" disabled>
                        <option hidden>選択できません</option>
                    </select>
                    <br>
                    <label for="third-vote7">コメント：</label>
                    <textarea id="third-vote7" name="third-vote7" col="60" row="1" disabled></textarea>
                    <br>
                    <br>
                    <button type="submit">決定</button>
                </form>
            </div>
            <p>
                <a href="../index.html">戻る</a>
            </p>
        </main>
        <footer></footer>
        <script src="../js/script.js"></script>
    </body>
</html>