<?php
    session_start();
    $_SESSION['err11'] = false;
    $_SESSION['err21'] = false;
    $_SESSION['err31'] = false;


    if(isset($_POST["second-vote1"])){
        if($_POST["second-vote1"] != "選択してください"){
            $firstVote1 = $_POST["first-vote1"];
            $secondVote1 = $_POST["second-vote1"];
            $thirdVote1 = $_POST["third-vote1"];
            $firstVote2 = '';
            $secondVote2 = '';
            $thirdVote2 = '';
            $firstVote3 = '';
            $secondVote3 = '';
            $thirdVote3 = '';
            $firstVote4 = '';
            $secondVote4 = '';
            $thirdVote4 = '';
            $firstVote5 = '';
            $secondVote5 = '';
            $thirdVote5 = '';
            $firstVote6 = '';
            $secondVote6 = '';
            $thirdVote6 = '';
            $firstVote7 = '';
            $secondVote7 = '';
            $thirdVote7 = '';
            
            $_SESSION['first-vote1-sub'] = $firstVote1;
            $_SESSION['second-vote1-sub'] = $secondVote1;
            $_SESSION['third-vote1-sub'] = $thirdVote1;
        }else{
            $_SESSION['err11'] = true;
        }
    }else{
        $_SESSION['err11'] = true;
    }

    if(isset($_POST["second-vote2"])){
        if($_POST["second-vote2"] != "選択してください"){
            $firstVote2 = $_POST["first-vote2"];
            $secondVote2 = $_POST["second-vote2"];
            $thirdVote2 = $_POST["third-vote2"];
            $firstVote3 = '';
            $secondVote3 = '';
            $firstVote4 = '';
            $secondVote4 = '';
            $firstVote5 = '';
            $secondVote5 = '';
            
            $_SESSION['first-vote2-sub'] = $firstVote2;
            $_SESSION['second-vote2-sub'] = $secondVote2;
            $_SESSION['third-vote2-sub'] = $thirdVote2;
        }else{
            $_SESSION['err21'] = true;
        }
    }else{
        $_SESSION['err21'] = true;
    }

    if(isset($_POST["second-vote3"])){
        if($_POST["second-vote3"] != "選択してください"){
            $firstVote3 = $_POST["first-vote3"];
            $secondVote3 = $_POST["second-vote3"];
            $thirdVote3 = $_POST["third-vote3"];
            $firstVote4 = '';
            $secondVote4 = '';
            $firstVote5 = '';
            $secondVote5 = '';
            
            $_SESSION['first-vote3-sub'] = $firstVote3;
            $_SESSION['second-vote3-sub'] = $secondVote3;
            $_SESSION['third-vote3-sub'] = $thirdVote3;
        }else{
            $_SESSION['err31'] = true;
        }
    }else{
        $_SESSION['err31'] = true;
    }

    if(isset($_POST["second-vote4"])){
        if($_POST["second-vote4"] != '選択してください'){
            $firstVote4 = $_POST["first-vote4"];
            $secondVote4 = $_POST["second-vote4"];
            $thirdVote4 = $_POST["third-vote4"];
            
            $_SESSION['first-vote4-sub'] = $firstVote4;
            $_SESSION['second-vote4-sub'] = $secondVote4;
            $_SESSION['third-vote4-sub'] = $thirdVote4;
        }
    }

    if(isset($_POST["second-vote5"])){
        if($_POST["second-vote5"] != '選択してください'){
            $firstVote5 = $_POST["first-vote5"];
            $secondVote5 = $_POST["second-vote5"];
            $thirdVote5 = $_POST["third-vote5"];
            
            $_SESSION['first-vote5-sub'] = $firstVote5;
            $_SESSION['second-vote5-sub'] = $secondVote5;
            $_SESSION['third-vote5-sub'] = $thirdVote5;
        }
    }

    if(isset($_POST["second-vote6"])){
        if($_POST["second-vote6"] != '選択してください'){
            $firstVote6 = $_POST["first-vote6"];
            $secondVote6 = $_POST["second-vote6"];
            $thirdVote6 = $_POST["third-vote6"];
            
            $_SESSION['first-vote6-sub'] = $firstVote6;
            $_SESSION['second-vote6-sub'] = $secondVote6;
            $_SESSION['third-vote6-sub'] = $thirdVote6;
        }
    }

    if(isset($_POST["second-vote7"])){
        if($_POST["second-vote7"] != '選択してください'){
            $firstVote7 = $_POST["first-vote7"];
            $secondVote7 = $_POST["second-vote7"];
            $thirdVote7 = $_POST["third-vote7"];
            
            $_SESSION['first-vote7-sub'] = $firstVote7;
            $_SESSION['second-vote7-sub'] = $secondVote7;
            $_SESSION['third-vote7-sub'] = $thirdVote7;
        }
    }

    if(
        $_SESSION['err11']
        || $_SESSION['err21']
        || $_SESSION['err31']
    ){
        header('location: main.php');
    }

?>
<!DOCTYPE html>
<html lang="ja">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="../css/styles.css" />
		<link rel="icon" href="../assets/image/iconF.ico">
        <title>投票アプリ</title>
    </head>
    <body>
        <nav></nav>
        <header></header>
        <main>
            <div class="pagehead">
                <h1>キャラクター部門</h1>
                <p>
                    1番推し～7番推しまで、最大で7人への投票が可能となっております。
                    4番推し～7番推しについては任意ですが、最低でも3人へは投票をしなければなりません。<br>
                    なお、コメント欄も用意しておりますが、こちらは必須項目ではありません。そのキャラクターに並々ならぬ熱意を持っている方はぜひとご活用ください。
                </p>
            </div>
            <div class="pagemid1">
                <p>
                    以下の投票内容でよろしいでしょうか？<br>
                    1番推し<br>
                    <?php
                        echo $firstVote1.' '.$secondVote1;
                        if($thirdVote1){
                            echo '<br>コメント：'.$thirdVote1;
                        }
                    ?><br>
                    <br>
                    2番推し<br>
                    <?php
                        echo $firstVote2.' '.$secondVote2;
                        if($thirdVote2){
                            echo '<br>コメント：'.$thirdVote2;
                        }
                    ?><br>
                    <br>
                    3番推し<br>
                    <?php   
                        echo $firstVote3.' '.$secondVote3;
                        if($thirdVote3){
                            echo '<br>コメント：'.$thirdVote3;
                        }
                    ?><br>
                    <br>
                    4番推し<br>
                    <?php   
                        if($secondVote4){
                            echo $firstVote4.' '.$secondVote4;
                            if($thirdVote4){
                                echo '<br>コメント：'.$thirdVote4;
                            }
                        }else{
                            echo '未記入';
                        }
                    ?><br>
                    <br>
                    4番推し<br>
                    <?php   
                        if($secondVote5){
                            echo $firstVote5.' '.$secondVote5;
                            if($thirdVote5){
                                echo '<br>コメント：'.$thirdVote5;
                            }
                        }else{
                            echo '未記入';
                        }
                    ?><br>
                    <br>
                    6番推し<br>
                    <?php   
                        if($secondVote6){
                            echo $firstVote6.' '.$secondVote6;
                            if($thirdVote6){
                                echo '<br>コメント：'.$thirdVote6;
                            }
                        }else{
                            echo '未記入';
                        }
                    ?><br>
                    <br>
                    7番推し<br>
                    <?php   
                        if($secondVote7){
                            echo $firstVote7.' '.$secondVote7;
                            if($thirdVote7){
                                echo '<br>コメント：'.$thirdVote7;
                            }
                        }else{
                            echo '未記入';
                        }
                    ?><br>
                    <form action="vote.php" method="POST">
                        <input type="hidden" name="first-vote1" value="<?php echo $firstVote1 ?>"></input>
                        <input type="hidden" name="first-vote2" value="<?php echo $firstVote2 ?>"></input>
                        <input type="hidden" name="first-vote3" value="<?php echo $firstVote3 ?>"></input>
                        <?php
                            if($firstVote4){
                                echo '<input type="hidden" name="first-vote4" value="'.$firstVote4.'"></input>';
                            }
                            if($firstVote5){
                                echo '<input type="hidden" name="first-vote5" value="'.$firstVote5.'"></input>';
                            }
                        ?>
                        <input type="hidden" name="second-vote1" value="<?php echo $secondVote1 ?>"></input>
                        <input type="hidden" name="second-vote2" value="<?php echo $secondVote2 ?>"></input>
                        <input type="hidden" name="second-vote3" value="<?php echo $secondVote3 ?>"></input>
                        <?php
                            if($secondVote4){
                                echo '<input type="hidden" name="second-vote2" value="'.$secondVote4.'"></input>';
                            }
                            if($secondVote5){
                                echo '<input type="hidden" name="second-vote3" value="'.$secondVote5.'"></input>';
                            }
                            if($secondVote6){
                                echo '<input type="hidden" name="second-vote2" value="'.$secondVote6.'"></input>';
                            }
                            if($secondVote7){
                                echo '<input type="hidden" name="second-vote3" value="'.$secondVote7.'"></input>';
                            }
                            
                            if($thirdVote1){
                                echo '<input type="hidden" name="third-vote4" value="'.$thirdVote1.'"></input>';
                            }
                            if($thirdVote2){
                                echo '<input type="hidden" name="third-vote5" value="'.$thirdVote2.'"></input>';
                            }
                            if($thirdVote3){
                                echo '<input type="hidden" name="third-vote6" value="'.$thirdVote3.'"></input>';
                            }
                            if($thirdVote4){
                                echo '<input type="hidden" name="third-vote4" value="'.$thirdVote4.'"></input>';
                            }
                            if($thirdVote5){
                                echo '<input type="hidden" name="third-vote5" value="'.$thirdVote5.'"></input>';
                            }
                            if($thirdVote6){
                                echo '<input type="hidden" name="third-vote6" value="'.$thirdVote6.'"></input>';
                            }
                            if($thirdVote7){
                                echo '<input type="hidden" name="third-vote7" value="'.$thirdVote7.'"></input>';
                            }
                        ?>
                        <button type="submit" class="a-btn">OK</button><br>
                        <a href="main.php">やり直す</a>
                    </form>
                </p>
            </div>
        </main>
        <footer></footer>
    </body>
</html>